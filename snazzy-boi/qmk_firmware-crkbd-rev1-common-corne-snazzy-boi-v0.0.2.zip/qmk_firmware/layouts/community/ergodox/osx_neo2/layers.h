enum layers {
  NEO_1,  // layer_0
  NEO_3,  // layer_1
  NEO_4,  // layer_2
  NEO_5,  // layer_3
  NEO_6,  // layer_4
  US_1,   // layer_5
  FKEYS   // layer_6
};